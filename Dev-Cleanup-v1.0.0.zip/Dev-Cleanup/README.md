# Dev Cleanup

Kostenloses Windows-Tool für nichtkommerzielle Nutzung. Windows PowerShell 5.1 genügt. Starte es mit deinem normalen Benutzerkonto.

1. ZIP vollständig entpacken.
2. Arbeit speichern und **Dev Cleanup.cmd** doppelklicken.
3. **Enter** startet den Durchlauf. Zum Abbrechen gib einen beliebigen Text ein.

Dev Cleanup zeigt die erkannten Programme vor dem Start an. Es bittet Fenster, sich regulär zu schließen, und beendet erkannte Hintergrundprozesse direkt. Dazu zählen auch Node.js und Python. Laufende Skripte, lokale Server und ungespeicherte Arbeit können betroffen sein.

Anschließend entfernt das Tool passende Dateien direkt im Benutzer-Temp-Ordner, die vor mehr als sieben Tagen erstellt und zuletzt geändert wurden. Es leert ausgewählte Standard-Caches vollständig geschlossener Browser. Favoriten, Cookies, Passwörter, Verlauf, Papierkorb und Windows-Dienste sind von der Bereinigung ausgenommen.

Lesetest in der Eingabeaufforderung: `"Dev Cleanup.cmd" -Check`.

## Lizenz

PolyForm Noncommercial License 1.0.0. Die Lizenz erlaubt nichtkommerzielle Nutzung. Details und ausdrücklich erlaubte Zwecke stehen in LICENSE.
