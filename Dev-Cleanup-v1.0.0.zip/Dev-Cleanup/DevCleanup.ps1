param([switch]$Check)

$ErrorActionPreference = 'Stop'
$apps = @(
    'opera', 'opera_gx', 'chrome', 'msedge', 'brave', 'firefox',
    'Code', 'Cursor', 'ChatGPT', 'Pinokio', 'Discord',
    'EpicGamesLauncher', 'EpicWebHelper', 'RobloxPlayerBeta', 'Docker Desktop', 
    'ollama app', 'ollama', 'python', 'node', 'uvicorn'
)
$session = (Get-Process -Id $PID).SessionId
$ownerSid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
$sessionProcesses = @(Get-CimInstance Win32_Process -Filter "SessionId = $session")
$parents = @{}
foreach ($entry in $sessionProcesses) {
    $parents[[int]$entry.ProcessId] = [int]$entry.ParentProcessId
}
$protected = [Collections.Generic.HashSet[int]]::new()
$ancestor = $PID
while ($ancestor -gt 0 -and $protected.Add($ancestor)) {
    $ancestor = $parents[$ancestor]
}

$windows = @(foreach ($app in (Get-Process -Name $apps -ErrorAction SilentlyContinue | Sort-Object ProcessName, Id)) {
    if ($app.SessionId -ne $session -or $protected.Contains($app.Id)) { continue }
    try {
        # Keep the process handle so a reused PID cannot target a different process.
        $null = $app.Handle
        $record = Get-CimInstance Win32_Process -Filter "ProcessId = $($app.Id)"
        if ($record -and (Invoke-CimMethod -InputObject $record -MethodName GetOwnerSid).Sid -eq $ownerSid -and -not $app.HasExited) {
            $app
        }
    } catch {
        # Processes can exit or deny access while the list is being built.
    }
})
$temp = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'Temp'
$cutoff = (Get-Date).ToUniversalTime().AddDays(-7)
function Get-OldTempFiles {
    $folder = Get-Item -LiteralPath $temp -Force
    if (-not $folder.PSIsContainer -or ($folder.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
        throw 'Der Temp-Ordner ist kein normaler Ordner.'
    }
    Get-ChildItem -LiteralPath $folder.FullName -File -Force | Where-Object {
        $_.CreationTimeUtc -lt $cutoff -and $_.LastWriteTimeUtc -lt $cutoff -and
        -not ($_.Attributes -band [IO.FileAttributes]::ReparsePoint)
    }
}

$localAppData = [Environment]::GetFolderPath('LocalApplicationData')
$browserRoots = @{
    brave = 'BraveSoftware\Brave-Browser\User Data'
    chrome = 'Google\Chrome\User Data'
    msedge = 'Microsoft\Edge\User Data'
    firefox = 'Mozilla\Firefox\Profiles'
    opera = 'Opera Software'
}
function Test-PlainDirectory([string]$path) {
    $directory = Get-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue
    if (-not $directory) { return $false }
    while ($directory) {
        if ($directory -isnot [IO.DirectoryInfo] -or ($directory.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
            return $false
        }
        $directory = $directory.Parent
    }
    return $true
}

function Get-CacheFiles([string]$path) {
    foreach ($item in (Get-ChildItem -LiteralPath $path -Force -ErrorAction SilentlyContinue)) {
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { continue }
        if ($item.PSIsContainer) { Get-CacheFiles $item.FullName }
        else { $item }
    }
}

function Get-BrowserCachePaths([string]$browser) {
    $root = Join-Path $localAppData $browserRoots[$browser]
    if (-not (Test-PlainDirectory $root)) { return }
    $cacheNames = @('Cache', 'Code Cache', 'GPUCache')
    if ($browser -eq 'firefox') { $cacheNames = @('cache2') }
    foreach ($browserProfile in (Get-ChildItem -LiteralPath $root -Directory)) {
        foreach ($name in $cacheNames) {
            $path = Join-Path $browserProfile.FullName $name
            if (Test-PlainDirectory $path) { $path }
        }
    }
}

function Clear-BrowserCaches {
    foreach ($browser in ($browserRoots.Keys | Sort-Object)) {
        $paths = @(Get-BrowserCachePaths $browser)
        if (-not $paths.Count) { continue }
        $processNames = @($browser)
        if ($browser -eq 'opera') { $processNames += 'opera_gx' }
        if (Get-Process -Name $processNames -ErrorAction SilentlyContinue) {
            Write-Host "$browser ist noch aktiv. Cache uebersprungen."
            continue
        }
        $removed = 0
        $skipped = 0
        foreach ($path in $paths) {
            Get-CacheFiles $path | ForEach-Object {
                try {
                    Remove-Item -LiteralPath $_.FullName -ErrorAction Stop
                    $removed++
                } catch {
                    $skipped++
                }
            }
        }
        Write-Host ("${browser}-Cache: {0} Dateien entfernt, {1} uebersprungen." -f $removed, $skipped)
    }
}

try {
    if ($Check) {
        $files = @(Get-OldTempFiles)
        Write-Output "Start OK. App-Prozesse: $($windows.Count). Temp-Dateien: $($files.Count)."
        foreach ($browser in ($browserRoots.Keys | Sort-Object)) { Write-Output ("${browser}: $(@(Get-BrowserCachePaths $browser).Count) Cache-Ordner") }
        exit 0
    }

    Write-Host 'Dev Cleanup' -ForegroundColor Cyan
    $selected = $windows
    foreach ($group in ($selected | Group-Object ProcessName)) {
        Write-Host ('  {0}: {1} Prozesse' -f $group.Name, $group.Count)
    }
    Write-Host 'Speichere zuerst deine Arbeit. Alle aufgefuehrten Apps werden verarbeitet.'
    Write-Host 'Fenster werden normal geschlossen. Hintergrundprozesse werden direkt beendet.'
    $files = @(Get-OldTempFiles)
    Write-Host ("Ausgewaehlte App-Prozesse: {0}. Alte Temp-Dateien: {1}." -f @($selected | Sort-Object Id -Unique).Count, $files.Count)
    if ((Read-Host 'Enter startet Beenden und Bereinigung. Andere Eingabe bricht ab') -ne '') {
        Write-Host 'Abgebrochen.'
        return
    }

    foreach ($app in ($selected | Sort-Object Id -Unique)) {
        try {
            if ($app.HasExited) { continue }
            if ($app.MainWindowHandle -eq [IntPtr]::Zero) {
                $app.Kill()
                if ($app.WaitForExit(2500)) {
                    Write-Host "$($app.ProcessName) (PID $($app.Id)) beendet."
                } else {
                    Write-Host "PID $($app.Id) noch aktiv." -ForegroundColor Yellow
                }
                continue
            }
            if ($app.CloseMainWindow() -and $app.WaitForExit(2500)) {
                Write-Host "$($app.ProcessName) geschlossen."
            } else {
                Write-Host "PID $($app.Id) noch aktiv. Pruefe das App-Fenster." -ForegroundColor Yellow
            }
        } catch {
            Write-Host "PID $($app.Id) konnte nicht geschlossen werden." -ForegroundColor Yellow
        }
    }

    $removed = 0
    $skipped = 0
    $bytes = 0L
    foreach ($file in (Get-OldTempFiles)) {
        try {
            Remove-Item -LiteralPath $file.FullName -ErrorAction Stop
            $removed++
            $bytes += $file.Length
        } catch {
            $skipped++
        }
    }
    Write-Host ('Temp-Dateien entfernt: {0}. Dateigroesse: {1:N2} MiB. Uebersprungen: {2}.' -f $removed, ($bytes / 1MB), $skipped)
    Clear-BrowserCaches
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    if ($Check) { exit 1 }
} finally {
    if (-not $Check) { [void](Read-Host 'Enter zum Schliessen') }
}






